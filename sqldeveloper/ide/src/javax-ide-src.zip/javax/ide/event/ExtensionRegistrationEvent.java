package javax.ide.event;

public class ExtensionRegistrationEvent
{
  private   String message;
  private   int totalCount, currentCount;
  private   Exception ex;
  
  
  public ExtensionRegistrationEvent(int totalCount,int currentCount, String message )
  {
    this.message=message;
    this.totalCount=totalCount;
    this.currentCount=currentCount;
  }
  
  public ExtensionRegistrationEvent(String message)
  {
    this.message=message;  
  }
  
  public ExtensionRegistrationEvent(Exception ex)
  {
    this.ex=ex;  
  }
  
  public int getCurrentCount()
  {
    return currentCount;
  }
  
  public int getTotalCount()
  {
    return totalCount;
  }
  
  public String getMessage()
  {
    return message;
  }
  
  public Exception getException()
  {
    return ex;
  }
}
