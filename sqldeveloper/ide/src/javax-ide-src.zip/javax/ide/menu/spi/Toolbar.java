/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.menu.spi;

public final class Toolbar extends SectionContainer
{
  public Toolbar( String id )
  { 
    super( id );
  }
}
