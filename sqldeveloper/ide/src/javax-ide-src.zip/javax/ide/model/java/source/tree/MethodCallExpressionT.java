/*
 * @(#)MethodCallExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression performing a method invocation or an explicit
 * constructor invocation. <p/>
 *
 * @author Andy Yu
 * */
public interface MethodCallExpressionT
  extends InvokeExpressionT, HasNameT
{
}
